package com.example.appletrackKD.Util;


import com.google.firebase.auth.FirebaseAuth;

public class configuraBd {


    private static FirebaseAuth auth;

    public static FirebaseAuth Firebaseautenticacao(){
        if (auth == null){
            auth = FirebaseAuth.getInstance();
        }
return auth;

    }

}
